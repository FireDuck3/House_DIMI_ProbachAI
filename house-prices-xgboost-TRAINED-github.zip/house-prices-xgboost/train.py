"""Навчання XGBoost для Kaggle House Prices.

Запуск:
    python train.py --data-dir data

Вхід: data/train.csv, data/test.csv
Вихід: models/house_prices_xgboost.joblib, results/metrics.json,
       results/submission.csv
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_squared_error
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from xgboost import XGBRegressor

SEED = 42
CANDIDATES = {
    "XGBoost_200": dict(n_estimators=200, learning_rate=0.05, max_depth=3,
                        subsample=0.85, colsample_bytree=0.85),
    "XGBoost_600": dict(n_estimators=600, learning_rate=0.03, max_depth=3,
                        subsample=0.85, colsample_bytree=0.85),
}


def build_pipeline(X: pd.DataFrame, params: dict) -> Pipeline:
    numeric_features = X.select_dtypes(include="number").columns.tolist()
    categorical_features = X.select_dtypes(exclude="number").columns.tolist()
    preprocessing = ColumnTransformer([
        ("numeric", SimpleImputer(strategy="median"), numeric_features),
        ("categorical", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encode", OneHotEncoder(handle_unknown="ignore")),
        ]), categorical_features),
    ])
    return Pipeline([
        ("preprocessor", preprocessing),
        ("model", XGBRegressor(objective="reg:squarederror", random_state=SEED,
                               n_jobs=2, **params)),
    ])


def main() -> None:
    parser = argparse.ArgumentParser(description="Train house-price XGBoost model")
    parser.add_argument("--data-dir", type=Path, default=Path("data"))
    args = parser.parse_args()

    train_csv = args.data_dir / "train.csv"
    test_csv = args.data_dir / "test.csv"
    if not train_csv.is_file() or not test_csv.is_file():
        raise FileNotFoundError(
            f"Не знайдено {train_csv} або {test_csv}. "
            "Завантажте обидва файли із Kaggle House Prices у папку data/."
        )

    train = pd.read_csv(train_csv)
    test = pd.read_csv(test_csv)
    if "SalePrice" not in train.columns or "Id" not in train.columns or "Id" not in test.columns:
        raise ValueError("Дані не схожі на Kaggle House Prices (немає SalePrice/Id).")
    X = train.drop(columns=["Id", "SalePrice"])
    y = np.log(train["SalePrice"])
    X_test = test.reindex(columns=X.columns)
    X_train, X_valid, y_train, y_valid = train_test_split(
        X, y, test_size=0.20, random_state=SEED
    )

    baseline = DummyRegressor(strategy="mean")
    baseline.fit(np.zeros((len(y_train), 1)), y_train)
    baseline_rmse = float(np.sqrt(mean_squared_error(
        y_valid, baseline.predict(np.zeros((len(y_valid), 1)))
    )))

    scores = {}
    for name, params in CANDIDATES.items():
        model = build_pipeline(X_train, params)
        model.fit(X_train, y_train)
        predictions = model.predict(X_valid)
        score = float(np.sqrt(mean_squared_error(y_valid, predictions)))
        scores[name] = score
        print(f"{name}: validation RMSE(log(SalePrice)) = {score:.5f}")

    best_name = min(scores, key=scores.get)
    best_model = build_pipeline(X, CANDIDATES[best_name])
    best_model.fit(X, y)  # Refit on all available labeled rows.

    model_dir = Path("models")
    results_dir = Path("results")
    model_dir.mkdir(parents=True, exist_ok=True)
    results_dir.mkdir(parents=True, exist_ok=True)

    model_file = model_dir / "house_prices_xgboost.joblib"
    joblib.dump(best_model, model_file)

    prices = np.exp(best_model.predict(X_test))
    pd.DataFrame({"Id": test["Id"], "SalePrice": prices}).to_csv(
        results_dir / "submission.csv", index=False
    )
    metrics = {
        "dataset": "Kaggle House Prices - Advanced Regression Techniques",
        "seed": SEED,
        "train_rows": int(len(train)),
        "validation_rows": int(len(y_valid)),
        "final_training_rows": int(len(X)),
        "baseline_rmse_log": baseline_rmse,
        "candidate_rmse_log": scores,
        "selected_model": best_name,
        "validation_rmse_log": scores[best_name],
        "target_transform": "natural logarithm",
        "validation_split": 0.20,
        "validation_note": "Single 80/20 holdout; validation scores are not Kaggle test scores",
    }
    (results_dir / "metrics.json").write_text(
        json.dumps(metrics, indent=2, ensure_ascii=False), encoding="utf-8"
    )

    assert model_file.exists()
    check = joblib.load(model_file)
    check_preds = check.predict(X_test.head(3))
    assert len(check_preds) == min(3, len(X_test))
    print(f"\nМодель збережена: {model_file}")
    print(f"Найкращий варіант: {best_name}")
    print(f"Baseline RMSE(log): {baseline_rmse:.5f}")
    print(f"Validation RMSE(log): {scores[best_name]:.5f}")
    print("Прогнози: results/submission.csv")
    print("Метрики: results/metrics.json")


if __name__ == "__main__":
    main()
