metrics.json — валідація; submission.csv — 1459 прогнозів для Kaggle.
