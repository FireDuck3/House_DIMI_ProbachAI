Модель house_prices_xgboost.joblib навчена на реальних 1460 рядках Kaggle train.csv.
