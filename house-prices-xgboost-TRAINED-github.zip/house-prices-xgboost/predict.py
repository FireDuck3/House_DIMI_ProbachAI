"""Отримати прогноз із уже натренованої моделі: python predict.py --input data/test.csv"""
import argparse
from pathlib import Path
import joblib
import numpy as np
import pandas as pd

parser = argparse.ArgumentParser()
parser.add_argument('--input', type=Path, default=Path('data/test.csv'))
parser.add_argument('--model', type=Path, default=Path('models/house_prices_xgboost.joblib'))
parser.add_argument('--output', type=Path, default=Path('results/predictions.csv'))
args = parser.parse_args()

model = joblib.load(args.model)  # Never load untrusted .joblib files.
test = pd.read_csv(args.input)
prices = np.exp(model.predict(test.drop(columns=['Id'])))
args.output.parent.mkdir(parents=True, exist_ok=True)
pd.DataFrame({'Id': test['Id'], 'SalePrice': prices}).to_csv(args.output, index=False)
print(f'Прогнози збережено у {args.output}')
