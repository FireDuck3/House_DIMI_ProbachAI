# House Prices — навчена модель XGBoost

**Завдання з машинного навчання:** спрогнозувати ціну продажу будинку за його характеристиками. Тип задачі — **supervised learning / regression**.

**Джерело даних:** [Kaggle — House Prices: Advanced Regression Techniques](https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques/data). Дані: **1460 рядків** `train.csv`, **1459 рядків** `test.csv`, 79 вхідних характеристик. Мета прогнозу — `SalePrice`.

## Результат реального навчання

Модель **дійсно навчена** на наданому Kaggle `train.csv`, збережена у файлі [`models/house_prices_xgboost.joblib`](models/house_prices_xgboost.joblib). Модель включає preprocessing і XGBRegressor.

| Модель | RMSE(log(SalePrice)) на валідації |
| --- | ---: |
| DummyRegressor (постійний середній прогноз) | **0.43325** |
| XGBoost, 200 дерев | **0.13196** |
| XGBoost, 600 дерев | **0.12657** — найкраща |

Випадковий поділ **80% / 20%** (`random_state=42`, 1168 навчальних і 292 валідаційних будинків). Метрика обчислена на натуральному логарифмі ціни. **Це не Kaggle leaderboard score**; змагання обчислює оцінку окремо після відправки CSV. Після оцінювання обраної конфігурації модель повторно навчено на **всіх 1460** відомих цінах.

### Як працює модель

1. Завантаження CSV, відділення мітки `SalePrice` і виключення `Id` з ознак.
2. Застосування `log(SalePrice)` до цільової змінної.
3. Заповнення числових пропусків медіаною; категоріальних — найчастішим значенням; One-Hot Encoding.
4. Навчання двох конфігурацій XGBoost, вибір меншої валідаційної помилки.
5. Повторне навчання на всіх навчальних даних, збереження `joblib` і генерація `submission.csv`.

Усі кроки preprocessing включено в `Pipeline`: вони навчаються **лише на навчальних рядках** під час валідації, без витоку з валідаційної вибірки.

## Структура проєкту

```text
house-prices-xgboost/
├── train.py                                 # Код навчання XGBoost
├── predict.py                               # Використання збереженої моделі
├── House_Prices_XGBoost_UA.ipynb            # Виконаний ноутбук з поясненнями, таблицями, графіками
├── models/
│   └── house_prices_xgboost.joblib          # РЕАЛЬНО натренована модель
├── results/
│   ├── metrics.json                         # Оцінка точності
│   └── submission.csv                       # Прогнози для 1459 будинків
├── data/
│   └── PUT_CSV_FILES_HERE.txt               # Інструкція з даними
├── requirements.txt
└── .gitignore
```

### Повторне навчання

Для повного відтворення завантажити `train.csv` і `test.csv` з [Kaggle](https://www.kaggle.com/competitions/house-prices-advanced-regression-techniques/data) в каталог `data/`:

```bash
python -m pip install -r requirements.txt
python train.py --data-dir data
```

Для **використання вже навченої** моделі (повторно тренувати не потрібно):

```bash
python predict.py --input data/test.csv --model models/house_prices_xgboost.joblib --output results/predictions.csv
```

Потрібен `test.csv` з Kaggle. Вихід — CSV зі стовпцями `Id` і `SalePrice`. Виконаний ноутбук можна переглянути **прямо на GitHub** без запуску.

> Для завантаження `.joblib` використовуйте лише довірені файли; цей формат може виконувати код при завантаженні. Python-бібліотеки для відкриття моделі бажано використовувати тих самих версій, що при навчанні: scikit-learn 1.8.0, XGBoost 3.1.3, numpy 2.3.5, pandas 2.2.3, joblib 1.5.3.

## Підсумок для захисту

Завдання: спрогнозувати ринкову ціну будинку на основі його характеристик. Використано алгоритм градієнтного бустингу XGBoost. Навчено два варіанти моделі та оцінено їх RMSE на валідації. Обрана модель з 600 деревами досягла **RMSE = 0.12657** на логарифмічній шкалі, що краще за базовий прогноз (**0.43325**). Модель перенавчено на всьому навчальному датасеті й збережено для повторного використання.
